
# Sales Page — Knockout Closers™

Voy a construir la sales page completa en `/` (index) aplicando fielmente tu **Global Brand Design System** (Deep Space Black, Nebula Navy, Royal Purple, Cosmic Violet, Electric Blue, Executive Gold, Titanium Silver) con la sensación Apple × OpenAI × Linear × Arc × Stripe. Copy 100% intacto tal como lo enviaste.

## Sistema visual (según tu brand doc)

- **Paleta** en `src/styles.css` con tokens oklch:
  - `--background: #05070D` (Deep Space Black)
  - `--surface: #0B1736` (Nebula Navy) · `--card: #101C42` (Midnight Surface)
  - `--primary: #6D3EFF` · `--accent-violet: #8B5CF6` · `--accent-blue: #2563FF`
  - `--gold: #D4AF37` · `--silver: #C7CCD6` · `--destructive: #D72638`
- Distribución 85% dark / 10% púrpura·azul / 5% oro·plata·rojo
- Gradientes definidos: Primary (135deg negro→navy→púrpura→azul), Secondary (vertical dark), Premium (oro→plata)
- Fondos atmosféricos con nebulosas suaves, partículas, luz volumétrica (opacidad máx 10%)
- Tipografía **Inter** (cargada por `<link>` en `__root.tsx`), headlines editorial bold, body 18px, ancho máx 70ch
- Botones: primario gradiente púrpura→azul, rounded-xl, glow suave, hover lift; secundario transparente con borde púrpura
- Cards glass, rounded-24px, borde suave, sombra sutil — nunca planas
- Iconos Lucide, outline thin
- Motion elegante: fade, translateY, blur, scale 1.02 (nada de bounce/spin)

## Estructura de la página (13 secciones + cierre)

```
/  (src/routes/index.tsx)
├── Hero               Headline + subheadline largo + CTA primario + texto de apoyo
├── S1  El cambio ya ocurrió + frase destacada
├── S2  El verdadero problema + bloque destacado
├── S3  El paradigma que ya no funciona + frase central
├── S4  Nueva generación (Knockout Professional™) + declaración + transición
├── S5  No es un curso, es sistema + frase destacada
├── S6  Qué encontrarás dentro (módulos) + bloque destacado
├── S7  ¿Para quién es? (checklist ✔ y ✖) + frase destacada
├── S8  ¿Por qué este momento? + frase destacada
├── S9  Resultados que trascienden + frase destacada
├── S10 Historias de evolución (3 bloques de testimonios + video documental)
├── S11 ¿Por qué funciona? + frase destacada
├── S12 Filosofía del Ring™ + frase destacada
├── S13 Próxima evolución + oferta + CTA principal + Garantía Knockout™ + FAQ + cierre
└── Footer minimal (logo + copyright)
```

Todo se compone en un solo route (`/`) para preservar el flujo narrativo de sales page, dividido en componentes por sección en `src/components/sales/` para mantenibilidad.

## Componentes clave

- `SectionShell` — wrapper con espaciado editorial y background atmosférico opcional
- `PullQuote` — frases destacadas grandes con acento de gradiente
- `HighlightBlock` — bloques destacados con card glass + borde púrpura sutil
- `CheckList` — checklist ✔/✖ con iconos Lucide
- `TestimonialCard` — ficha documental (foto, nombre, cargo, empresa, extracto, link LinkedIn opcional) — placeholder para foto hasta que envíes las reales
- `VideoDocumentary` — bloque de video embebido (placeholder responsive 16:9 con overlay premium) hasta que envíes URL/archivo
- `FAQItem` — acordeón minimalista
- `PrimaryCTA` / `SecondaryCTA` — botones del sistema
- `AtmosphericBackground` — capa fija de nebulosa/partículas SVG con opacidad ≤10%

## SEO / head

`head()` en `src/routes/index.tsx` con:
- title: "Knockout Closers™ — Evoluciona tu perfil profesional"
- description basada en el subheadline del hero
- og:title, og:description, og:type=website, twitter:card=summary_large_image
- H1 único = headline del hero
- Alt text en todas las imágenes, lazy loading en testimoniales

## Notas / cosas que necesito de ti (no bloquean, uso placeholders elegantes)

1. **Destino del CTA principal** (`Quiero convertirme en un Knockout Professional™`): ¿Calendly, WhatsApp, checkout Stripe, formulario? Por ahora enlazará a `#oferta` (ancla al bloque final).
2. **Fotos y links de LinkedIn** para los 9 testimonios (Miguel Ángel Vega, Verónica Díaz, Beatriz Morales, Bernardo Brizuela, Carlos Cañas, Marina Colín, Claudia Espinosa, Karina Payán, Roberto Valdez). Uso iniciales sobre gradiente premium mientras.
3. **Video documental**: URL de YouTube/Vimeo o archivo. Uso un poster placeholder con botón play.
4. **Logo oficial Knockout Closers™**: si tienes SVG/PNG lo integro en header/footer. Uso wordmark tipográfico premium mientras.

Puedo empezar de inmediato con estos placeholders y sustituirlos cuando me pases los assets.

## Detalle técnico

- Framework fijo: TanStack Start + Tailwind v4 + shadcn (ya presentes)
- `src/styles.css`: reescribo tokens `:root` con la paleta del brand (todo en oklch), añado gradientes como variables, y `@theme inline` para exponerlos como utilidades
- Fuente Inter vía `<link>` en `src/routes/__root.tsx` (nunca `@import` remoto)
- Animaciones con clases Tailwind + `motion` (fade/translateY/blur) — sin dependencias nuevas si el proyecto ya tiene tw-animate-css (lo tiene)
- Sin backend: es puramente presentacional. No enciendo Lovable Cloud hasta que decidas capturar leads
- Reemplazo el placeholder de `src/routes/index.tsx`
